<?php
if (isset($_POST['submit'])){
	$_firstname = $_POST['firstname'];
	$_lastname = $_POST['lastname'];
	$_email = $_POST['email'];	
	$_username = $_POST['username'];
	$_password = $_POST['password'];
	
	include("databaseconnect.php");
	
	$sql = "INSERT INTO user(first_name,last_name,email,username,password) values ('$firstname','$lastname','$email','$username','$password')";
	$result=mysqli_query($conn,$sql);
	if(result){
		echo("Data inserted successfully" );
	}else{
		die(mysql_error());
	}
}
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>ConceptPalace</title>
	<link rel="stylesheet" type="text/css" href="css/cpstylesheet.css">
	<link rel="stylesheet" type="text/css" href="css/Login_Signup.css">
	
</head>

<body>
	<header>
	<h1>ConceptPalace</h1>
    <h5>Inspiration Through Innovation</h5>
	</header>
	
		<section class="forms-section">
  <h1 class="section-title">Login & Signup Forms</h1>
  <div class="forms">
    <div class="form-wrapper is-active">
      <button type="button" class="switcher switcher-login">
        Login
        <span class="underline"></span>
      </button>
      <form class="form form-login">
        <fieldset>
          <legend>Please, enter your email and password for login.</legend>
          <div class="input-block">
            <label for="login-email">E-mail</label>
            <input id="login-email" type="email" required>
          </div>
          <div class="input-block">
            <label for="login-password">Password</label>
            <input id="login-password" type="password" required>
          </div>
        </fieldset>
        <button type="submit" class="btn-login">Login</button>
      </form>
    </div>
    <div class="form-wrapper">
      <button type="button" class="switcher switcher-signup">
        Sign Up
        <span class="underline"></span>
      </button>
      <form class="form form-signup">
        <fieldset>
          <legend>Please, enter your email, password and password confirmation for sign up.</legend>
          <div class="input-block">
            <label for="signup-firstname">First Name</label>
            <input id="signup-firstname" type="text" required>
          </div>
		  <div class="input-block">
			<label for="signup-lastname">Last Name</label>
            <input id="signup-lastname" type="text" required>
          </div>
          <div class="input-block">
            <label for="signup-email">E-mail</label>
            <input id="signup-email" type="email" required>
          </div>
		  <div class="input-block">
			<label for="signup-username">Username</label>
            <input id="signup-username" type="text" required>
          </div>
          <div class="input-block">
            <label for="signup-password">Password</label>
            <input id="signup-password" type="password" required>
          </div>
        </fieldset>
        <button type="submit" class="btn-signup">Sign Up</button>
      </form>
    </div>
  </div>
</section>
	
	<script>
	const switchers = [...document.querySelectorAll('.switcher')]

switchers.forEach(item => {
	item.addEventListener('click', function() {
		switchers.forEach(item => item.parentElement.classList.remove('is-active'))
		this.parentElement.classList.add('is-active')
	})
})

	</script>
	<footer>
	<h1>ConceptPalace</h1>
<h5>Inspiration Through Innovation</h5>
<h6> &copy ConceptPalace 2025 </h6>
	</footer>
</body>

</html>