<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
	<link rel="stylesheet" type="text/css" href="css/cpstylesheet.css">

</head>

<body>
	<ul id="products">
    <li data-productid="1">Product 1 <button class="add-to-cart">Add to Cart</button></li>
    <li data-productid="2">Product 2 <button class="add-to-cart">Add to Cart</button></li>
    <li data-productid="3">Product 3 <button class="add-to-cart">Add to Cart</button></li>
</ul>

<ul id="cart">
    <!-- Cart items will be added here dynamically -->
</ul>
	<script>
//Add to Cart
document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', function() {
        const productId = this.parentElement.getAttribute('data-productid');
        const productName = this.parentElement.textContent.trim().split(' ')[0];
        
        const cartItem = document.createElement('li');
        cartItem.innerHTML = `${productName} <button class="remove-from-cart">Remove</button>`;
        cartItem.setAttribute('data-productid', productId);
        
        document.getElementById('cart').appendChild(cartItem);
    });
});
	</script>
	<script>
//Remove from Cart
document.getElementById('cart').addEventListener('click', function(e) {
    if (e.target.classList.contains('remove-from-cart')) {
        e.target.parentElement.remove();
    }
});</script>
</body>
</html>