// JavaScript Document

document.querySelectorAll('img').forEach(img => {
  img.addEventListener('click', e => {
    document.getElementById('image').src = e.target.src;
    document.getElementById('lightbox').style.display = 'flex';
  });
});

document.getElementById('close').addEventListener('click', () => {
  document.getElementById('lightbox').style.display = 'none';
});